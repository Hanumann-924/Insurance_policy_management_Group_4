export class User {
    username:string;
    password:string;
    email:string;
    phone:string;
    role:string;
    age:string;
}