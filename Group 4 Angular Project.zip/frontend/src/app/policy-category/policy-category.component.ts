import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-policy-category',
  templateUrl: './policy-category.component.html',
  styleUrls: ['./policy-category.component.css']
})
export class PolicyCategoryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
