export class Policy {
    policyno:number;
    category:string;
    policyname:string;
    premium:string;
	maturity:string;
}