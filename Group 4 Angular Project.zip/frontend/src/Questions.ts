export class Questions {
    qid:number;
    question:string;
    answer:string;
   customername:string;
}