export class Record {
    recordno:number;
    category:string;
    policyname:string;
    customername:string;
    date:Date;
    status:string;
}